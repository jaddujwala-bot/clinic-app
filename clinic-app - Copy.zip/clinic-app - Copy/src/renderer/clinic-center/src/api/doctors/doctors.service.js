// Doctor Service - business logic for doctor/staff management
const { prisma } = require('../db');

const DoctorService = {
  async list({ search } = {}) {
    const where = search
      ? {
          OR: [
            { name: { contains: search } },
            { specialty: { contains: search } },
          ],
        }
      : {};
    return prisma.doctor.findMany({ where, orderBy: { name: 'asc' } });
  },

  async getById(id) {
    return prisma.doctor.findUnique({
      where: { id: Number(id) },
      include: { appointments: true },
    });
  },

  async create(data) {
    return prisma.doctor.create({
      data: {
        name: data.name,
        specialty: data.specialty,
        phone: data.phone || null,
        email: data.email || null,
      },
    });
  },

  async update(id, data) {
    return prisma.doctor.update({
      where: { id: Number(id) },
      data,
    });
  },

  async remove(id) {
    return prisma.doctor.delete({ where: { id: Number(id) } });
  },
};

module.exports = { DoctorService };
