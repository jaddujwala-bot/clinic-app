// API client wrapper for the renderer.
// In Electron, window.clinicAPI is injected by the preload script.
// When running in a plain browser (react-scripts start without Electron),
// we surface a clear error so screens can show a helpful message.

const missing = () => {
  throw new Error(
    'clinicAPI is not available. Run the app through Electron (npm run dev) so the backend bridge is loaded.'
  );
};

// Build a proxy that mirrors the clinicAPI shape but throws if not in Electron.
function getAPI() {
  if (typeof window !== 'undefined' && window.clinicAPI) {
    return window.clinicAPI;
  }
  return {
    patients: new Proxy({}, { get: () => missing }),
    doctors: new Proxy({}, { get: () => missing }),
    appointments: new Proxy({}, { get: () => missing }),
    medicines: new Proxy({}, { get: () => missing }),
    pharmacy: new Proxy({}, { get: () => missing }),
    billing: new Proxy({}, { get: () => missing }),
    visits: new Proxy({}, { get: () => missing }),
    prescriptions: new Proxy({}, { get: () => missing }),
    reports: new Proxy({}, { get: () => missing }),
  };
}

export const api = getAPI();

export const isElectron = () =>
  typeof window !== 'undefined' && !!window.clinicAPI;
