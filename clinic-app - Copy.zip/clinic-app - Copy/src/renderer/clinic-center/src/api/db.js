// Prisma Client singleton
// Provides a single shared PrismaClient instance across the app.
const { PrismaClient } = require('@prisma/client');

let prisma;

if (!global.__prisma) {
  global.__prisma = new PrismaClient();
}
prisma = global.__prisma;

module.exports = { prisma };
