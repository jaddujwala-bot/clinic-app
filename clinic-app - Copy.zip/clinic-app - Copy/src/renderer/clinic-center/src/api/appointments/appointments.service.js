// Appointment Service - scheduling business logic
const { prisma } = require('../db');

const AppointmentService = {
  // List appointments, optionally filtered by date range or status
  async list({ from, to, status, patientId, doctorId } = {}) {
    const where = {};
    if (status) where.status = status;
    if (patientId) where.patientId = Number(patientId);
    if (doctorId) where.doctorId = Number(doctorId);
    if (from || to) {
      where.datetime = {};
      if (from) where.datetime.gte = new Date(from);
      if (to) where.datetime.lte = new Date(to);
    }
    return prisma.appointment.findMany({
      where,
      include: { patient: true, doctor: true },
      orderBy: { datetime: 'asc' },
    });
  },

  async getById(id) {
    return prisma.appointment.findUnique({
      where: { id: Number(id) },
      include: { patient: true, doctor: true },
    });
  },

  async create(data) {
    return prisma.appointment.create({
      data: {
        patientId: Number(data.patientId),
        doctorId: Number(data.doctorId),
        datetime: new Date(data.datetime),
        status: data.status || 'scheduled',
        notes: data.notes || null,
      },
      include: { patient: true, doctor: true },
    });
  },

  async update(id, data) {
    const updateData = { ...data };
    if (data.datetime) updateData.datetime = new Date(data.datetime);
    if (data.patientId) updateData.patientId = Number(data.patientId);
    if (data.doctorId) updateData.doctorId = Number(data.doctorId);
    return prisma.appointment.update({
      where: { id: Number(id) },
      data: updateData,
      include: { patient: true, doctor: true },
    });
  },

  // Change appointment status (scheduled/completed/cancelled/no-show)
  async setStatus(id, status) {
    return prisma.appointment.update({
      where: { id: Number(id) },
      data: { status },
    });
  },

  async remove(id) {
    return prisma.appointment.delete({ where: { id: Number(id) } });
  },
};

module.exports = { AppointmentService };
