// Pharmacy Service - medicine inventory & dispensing logic
const { prisma } = require('../db');

const PharmacyService = {
  // ---- Medicine inventory ----
  async listMedicines({ search, lowStock } = {}) {
    const where = {};
    if (search) {
      where.OR = [
        { name: { contains: search } },
        { genericName: { contains: search } },
        { batchNumber: { contains: search } },
      ];
    }
    if (lowStock) where.quantity = { lte: 10 };
    return prisma.medicine.findMany({ where, orderBy: { name: 'asc' } });
  },

  async getMedicine(id) {
    return prisma.medicine.findUnique({ where: { id: Number(id) } });
  },

  async createMedicine(data) {
    return prisma.medicine.create({
      data: {
        name: data.name,
        genericName: data.genericName || null,
        batchNumber: data.batchNumber,
        expiryDate: new Date(data.expiryDate),
        quantity: Number(data.quantity) || 0,
        unitPrice: Number(data.unitPrice),
        supplier: data.supplier || null,
      },
    });
  },

  async updateMedicine(id, data) {
    const updateData = { ...data };
    if (data.expiryDate) updateData.expiryDate = new Date(data.expiryDate);
    if (data.quantity !== undefined) updateData.quantity = Number(data.quantity);
    if (data.unitPrice !== undefined) updateData.unitPrice = Number(data.unitPrice);
    return prisma.medicine.update({
      where: { id: Number(id) },
      data: updateData,
    });
  },

  async removeMedicine(id) {
    return prisma.medicine.delete({ where: { id: Number(id) } });
  },

  // ---- Dispensing: issue medicine to a patient ----
  // Decrements stock, records a PharmacyTransaction, and creates a Billing entry.
  async dispense({ patientId, medicineId, quantity, prescriptionId, dispensedBy }) {
    const qty = Number(quantity);
    return prisma.$transaction(async (tx) => {
      const medicine = await tx.medicine.findUnique({
        where: { id: Number(medicineId) },
      });
      if (!medicine) throw new Error('Medicine not found');
      if (medicine.quantity < qty) {
        throw new Error(
          `Insufficient stock. Available: ${medicine.quantity}, requested: ${qty}`
        );
      }

      const totalAmount = medicine.unitPrice * qty;

      // 1. Decrement stock
      await tx.medicine.update({
        where: { id: medicine.id },
        data: { quantity: medicine.quantity - qty },
      });

      // 2. Record the pharmacy transaction
      const transaction = await tx.pharmacyTransaction.create({
        data: {
          patientId: Number(patientId),
          medicineId: medicine.id,
          prescriptionId: prescriptionId ? Number(prescriptionId) : null,
          quantity: qty,
          unitPrice: medicine.unitPrice,
          totalAmount,
          dispensedBy: dispensedBy || null,
          status: 'completed',
        },
      });

      // 3. Create a billing entry for the dispensed medicine
      const billing = await tx.billing.create({
        data: {
          patientId: Number(patientId),
          item: `Medicine: ${medicine.name}`,
          description: `${qty} x ${medicine.name} @ ${medicine.unitPrice}`,
          amount: totalAmount,
          status: 'pending',
        },
      });

      return { transaction, billing };
    });
  },

  // Transaction history
  async listTransactions({ patientId } = {}) {
    const where = patientId ? { patientId: Number(patientId) } : {};
    return prisma.pharmacyTransaction.findMany({
      where,
      include: { patient: true, medicine: true },
      orderBy: { dispensedAt: 'desc' },
    });
  },
};

module.exports = { PharmacyService };
