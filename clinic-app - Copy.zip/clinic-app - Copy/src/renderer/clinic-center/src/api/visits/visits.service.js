// Visit Service - clinical visit records & prescriptions
const { prisma } = require('../db');

const VisitService = {
  async list({ patientId, doctorId } = {}) {
    const where = {};
    if (patientId) where.patientId = Number(patientId);
    if (doctorId) where.doctorId = Number(doctorId);
    return prisma.visit.findMany({
      where,
      include: { patient: true, doctor: true },
      orderBy: { visitDate: 'desc' },
    });
  },

  async getById(id) {
    return prisma.visit.findUnique({
      where: { id: Number(id) },
      include: { patient: true, doctor: true },
    });
  },

  async create(data) {
    return prisma.visit.create({
      data: {
        patientId: Number(data.patientId),
        doctorId: Number(data.doctorId),
        visitDate: new Date(data.visitDate || Date.now()),
        symptoms: data.symptoms || null,
        diagnosis: data.diagnosis || null,
        treatment: data.treatment || null,
        notes: data.notes || null,
      },
    });
  },

  async update(id, data) {
    const updateData = { ...data };
    if (data.visitDate) updateData.visitDate = new Date(data.visitDate);
    return prisma.visit.update({
      where: { id: Number(id) },
      data: updateData,
    });
  },

  async remove(id) {
    return prisma.visit.delete({ where: { id: Number(id) } });
  },
};

// ---- Prescriptions ----
const PrescriptionService = {
  async list({ patientId } = {}) {
    const where = patientId ? { patientId: Number(patientId) } : {};
    return prisma.prescription.findMany({
      where,
      include: { patient: true, doctor: true, medicine: true },
      orderBy: { issuedAt: 'desc' },
    });
  },

  async create(data) {
    return prisma.prescription.create({
      data: {
        patientId: Number(data.patientId),
        doctorId: Number(data.doctorId),
        medicineId: Number(data.medicineId),
        dosage: data.dosage,
        frequency: data.frequency,
        duration: Number(data.duration),
        quantity: Number(data.quantity),
        instructions: data.instructions || null,
        status: data.status || 'active',
      },
      include: { medicine: true },
    });
  },

  async setStatus(id, status) {
    return prisma.prescription.update({
      where: { id: Number(id) },
      data: { status },
    });
  },

  async remove(id) {
    return prisma.prescription.delete({ where: { id: Number(id) } });
  },
};

module.exports = { VisitService, PrescriptionService };
