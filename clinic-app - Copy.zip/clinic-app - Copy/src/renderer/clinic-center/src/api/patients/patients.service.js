// Patient Service - business logic for patient management
const { prisma } = require('../db');

const PatientService = {
  // List all patients, optional search by name/phone/email
  async list({ search } = {}) {
    const where = search
      ? {
          OR: [
            { name: { contains: search } },
            { phone: { contains: search } },
            { email: { contains: search } },
          ],
        }
      : {};
    return prisma.patient.findMany({
      where,
      orderBy: { createdAt: 'desc' },
    });
  },

  // Get a single patient with related records
  async getById(id) {
    return prisma.patient.findUnique({
      where: { id: Number(id) },
      include: {
        appointments: { include: { doctor: true } },
        prescriptions: { include: { medicine: true, doctor: true } },
        billings: true,
        visits: { include: { doctor: true } },
      },
    });
  },

  // Create a new patient
  async create(data) {
    return prisma.patient.create({
      data: {
        name: data.name,
        dob: new Date(data.dob),
        gender: data.gender,
        phone: data.phone || null,
        email: data.email || null,
        address: data.address || null,
      },
    });
  },

  // Update an existing patient
  async update(id, data) {
    const updateData = { ...data };
    if (data.dob) updateData.dob = new Date(data.dob);
    return prisma.patient.update({
      where: { id: Number(id) },
      data: updateData,
    });
  },

  // Delete a patient
  async remove(id) {
    return prisma.patient.delete({ where: { id: Number(id) } });
  },
};

module.exports = { PatientService };
