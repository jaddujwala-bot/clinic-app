// Billing Service - invoices & payments
const { prisma } = require('../db');

const BillingService = {
  async list({ patientId, status } = {}) {
    const where = {};
    if (patientId) where.patientId = Number(patientId);
    if (status) where.status = status;
    return prisma.billing.findMany({
      where,
      include: { patient: true },
      orderBy: { createdAt: 'desc' },
    });
  },

  async getById(id) {
    return prisma.billing.findUnique({
      where: { id: Number(id) },
      include: { patient: true },
    });
  },

  async create(data) {
    return prisma.billing.create({
      data: {
        patientId: Number(data.patientId),
        appointmentId: data.appointmentId ? Number(data.appointmentId) : null,
        item: data.item,
        description: data.description || null,
        amount: Number(data.amount),
        status: data.status || 'pending',
        paidAmount: Number(data.paidAmount) || 0,
      },
      include: { patient: true },
    });
  },

  async update(id, data) {
    const updateData = { ...data };
    if (data.amount !== undefined) updateData.amount = Number(data.amount);
    if (data.paidAmount !== undefined) updateData.paidAmount = Number(data.paidAmount);
    return prisma.billing.update({
      where: { id: Number(id) },
      data: updateData,
    });
  },

  // Record a payment against a bill; auto-updates status
  async recordPayment(id, amount) {
    const bill = await prisma.billing.findUnique({ where: { id: Number(id) } });
    if (!bill) throw new Error('Bill not found');
    const newPaid = bill.paidAmount + Number(amount);
    let status = 'partially_paid';
    if (newPaid >= bill.amount) status = 'paid';
    else if (newPaid <= 0) status = 'pending';
    return prisma.billing.update({
      where: { id: Number(id) },
      data: { paidAmount: newPaid, status },
    });
  },

  async remove(id) {
    return prisma.billing.delete({ where: { id: Number(id) } });
  },

  // Summary totals for reporting
  async summary({ from, to } = {}) {
    const where = {};
    if (from || to) {
      where.createdAt = {};
      if (from) where.createdAt.gte = new Date(from);
      if (to) where.createdAt.lte = new Date(to);
    }
    const bills = await prisma.billing.findMany({ where });
    const totalBilled = bills.reduce((s, b) => s + b.amount, 0);
    const totalPaid = bills.reduce((s, b) => s + b.paidAmount, 0);
    return {
      count: bills.length,
      totalBilled,
      totalPaid,
      outstanding: totalBilled - totalPaid,
    };
  },
};

module.exports = { BillingService };
