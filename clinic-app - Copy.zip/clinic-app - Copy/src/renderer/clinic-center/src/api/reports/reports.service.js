// Reports Service - analytics across patients, doctors, and pharmacy
const { prisma } = require('../db');

const ReportsService = {
  // Overview KPIs for dashboard
  async overview() {
    const [patients, doctors, appointments, medicines] = await Promise.all([
      prisma.patient.count(),
      prisma.doctor.count(),
      prisma.appointment.count(),
      prisma.medicine.count(),
    ]);
    const bills = await prisma.billing.findMany();
    const revenue = bills.reduce((s, b) => s + b.paidAmount, 0);
    const outstanding = bills.reduce((s, b) => s + (b.amount - b.paidAmount), 0);
    return { patients, doctors, appointments, medicines, revenue, outstanding };
  },

  // Patient report: visit count, spend
  async patientReport({ from, to } = {}) {
    const dateFilter = {};
    if (from) dateFilter.gte = new Date(from);
    if (to) dateFilter.lte = new Date(to);

    const patients = await prisma.patient.findMany({
      include: {
        visits: true,
        billings: true,
        appointments: true,
      },
    });
    return patients.map((p) => ({
      id: p.id,
      name: p.name,
      visits: p.visits.length,
      appointments: p.appointments.length,
      totalBilled: p.billings.reduce((s, b) => s + b.amount, 0),
      totalPaid: p.billings.reduce((s, b) => s + b.paidAmount, 0),
    }));
  },

  // Doctor report: appointments and visits handled
  async doctorReport() {
    const doctors = await prisma.doctor.findMany({
      include: { appointments: true },
    });
    return doctors.map((d) => ({
      id: d.id,
      name: d.name,
      specialty: d.specialty,
      appointments: d.appointments.length,
      completed: d.appointments.filter((a) => a.status === 'completed').length,
    }));
  },

  // Pharmacy report: dispensing volume and revenue
  async pharmacyReport({ from, to } = {}) {
    const where = {};
    if (from || to) {
      where.dispensedAt = {};
      if (from) where.dispensedAt.gte = new Date(from);
      if (to) where.dispensedAt.lte = new Date(to);
    }
    const transactions = await prisma.pharmacyTransaction.findMany({
      where,
      include: { medicine: true },
    });
    const byMedicine = {};
    let totalRevenue = 0;
    for (const t of transactions) {
      totalRevenue += t.totalAmount;
      const key = t.medicine.name;
      if (!byMedicine[key]) byMedicine[key] = { name: key, quantity: 0, revenue: 0 };
      byMedicine[key].quantity += t.quantity;
      byMedicine[key].revenue += t.totalAmount;
    }
    return {
      totalTransactions: transactions.length,
      totalRevenue,
      byMedicine: Object.values(byMedicine),
    };
  },
};

module.exports = { ReportsService };
