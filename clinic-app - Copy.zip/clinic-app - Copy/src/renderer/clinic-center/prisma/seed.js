// Seed script - populates the clinic database with sample data
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function main() {
  console.log('Seeding clinic database...');

  // Doctors
  const drSmith = await prisma.doctor.create({
    data: { name: 'Dr. Sarah Smith', specialty: 'General Physician', phone: '555-0101', email: 'sarah.smith@clinic.com' },
  });
  const drKhan = await prisma.doctor.create({
    data: { name: 'Dr. Imran Khan', specialty: 'Cardiology', phone: '555-0102', email: 'imran.khan@clinic.com' },
  });

  // Patients
  const p1 = await prisma.patient.create({
    data: { name: 'John Doe', dob: new Date('1985-04-12'), gender: 'Male', phone: '555-1001', email: 'john.doe@email.com', address: '12 Oak Street' },
  });
  const p2 = await prisma.patient.create({
    data: { name: 'Maria Garcia', dob: new Date('1992-09-30'), gender: 'Female', phone: '555-1002', email: 'maria.g@email.com', address: '48 Pine Avenue' },
  });

  // Medicines
  const med1 = await prisma.medicine.create({
    data: { name: 'Paracetamol 500mg', genericName: 'Acetaminophen', batchNumber: 'PCM-2026-A', expiryDate: new Date('2027-12-31'), quantity: 500, unitPrice: 0.15, supplier: 'MediSupply Co.' },
  });
  const med2 = await prisma.medicine.create({
    data: { name: 'Amoxicillin 250mg', genericName: 'Amoxicillin', batchNumber: 'AMX-2026-B', expiryDate: new Date('2027-06-30'), quantity: 200, unitPrice: 0.40, supplier: 'PharmaDist Ltd.' },
  });

  // Appointment
  await prisma.appointment.create({
    data: { patientId: p1.id, doctorId: drSmith.id, datetime: new Date(Date.now() + 86400000), status: 'scheduled', notes: 'Routine checkup' },
  });

  // Visit + prescription
  const visit = await prisma.visit.create({
    data: { patientId: p2.id, doctorId: drKhan.id, visitDate: new Date(), symptoms: 'Chest discomfort', diagnosis: 'Mild hypertension', treatment: 'Lifestyle changes + medication' },
  });
  await prisma.prescription.create({
    data: { patientId: p2.id, doctorId: drKhan.id, medicineId: med1.id, dosage: '1 tablet', frequency: 'twice daily', duration: 7, quantity: 14, instructions: 'After meals' },
  });

  // Billing
  await prisma.billing.create({
    data: { patientId: p1.id, item: 'Consultation', description: 'General consultation fee', amount: 50.0, status: 'pending' },
  });

  console.log('Seeding complete.');
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(async () => { await prisma.$disconnect(); });
