# Multi-speciality Clinic + Pharmacy Management System

This project now includes both:

1. **CMS / Clinic Management System**
2. **Pharmacy Management Module**

It runs locally using Python + SQLite + HTML/CSS/JavaScript.

## How to run

```bash
cd clinic-app
python server.py
```

If your computer uses `python3`:

```bash
python3 server.py
```

Open in browser:

```text
http://localhost:8000
```

## Login credentials for testing

Please change these passwords before real use.

| Role | Username | Password | Access |
|---|---|---|---|
| Admin | `admin` | `admin123` | CMS + Pharmacy |
| Receptionist | `reception` | `reception123` | CMS |
| Doctor | `doctor` | `doctor123` | CMS + read-only stock inventory |
| Pharmacist | `pharmacy` | `pharmacy123` | Pharmacy only |

## CMS modules included

- Dashboard
- Patient Registration with unique UHID
- Patient Directory
- OPD Billing
- Doctor fee auto-pick
- Payment status: Paid, Unpaid, Partial Paid
- Printable OPD invoice
- Printable prescription
- Appointments
- Reports
- Admin: Employees, Doctors, Departments/Sub-departments
- Admin database backup
- Audit logging

## Pharmacy modules included

### 1. Pharmacy Dashboard

- Today’s revenue
- Active invoices
- Low stock items
- Soon-to-expire items
- Weekly sales trend graph
- Low stock by category chart
- Recent invoices
- Alerts and notifications
- Buttons for New Invoice and Stock Inward

### 2. Create Invoice

- Customer information
- Registered patient filter by clinic registration number
- Manual walk-in customer entry
- Payment status and payment method
- Medicine item rows with Add Row
- Medicine, Qty, Rate, CGST, SGST and Total
- CGST 2.5% and SGST 2.5%
- Accurate billing summary
- Discount percentage
- Payment received and remaining balance
- Print Invoice
- Save Invoice
- Export to Excel-compatible CSV

### 3. Return Medicine

- Total Return
- Total Refund
- Pending
- Paid
- Return request creation
- Invoice selection
- Auto-filled customer and invoice details
- Items to return
- Return quantity entry
- Refund summary
- Mark Paid and Restore Stock with confirmation

### 4. Sales Invoice

- Total invoices
- Total revenue
- Paid
- Draft
- Filter/search
- Invoice list
- Print invoice
- Edit/delete according to role permissions

### 5. Purchase Order

- Total orders
- Active orders
- Added to stock
- Draft orders
- Create New PO button redirects to Add Stock

### 6. Add Stock

- Multiple medicine line items
- Medicine name
- Batch number
- Quantity
- Cost per quantity
- Selling price
- MRP
- HSN
- CGST/SGST default 2.5%
- Expiry date calendar
- Supplier information
- Invoice/reference number
- Payment status
- Save Draft
- Confirm and Add Stock
- Print

### 7. Stock Inventory

- Total items
- Low stock
- Out of stock
- Expiring soon
- Search/filter
- Batch-wise stock table
- PO number
- Invoice number
- Expiry date
- Category
- Supplier
- History column
- Print
- Export to Excel-compatible CSV

### 8. Master Data

- Add Unit
- Add HSN
- Add Manufacturer
- Add Location
- Add Supplier

### 9. Pharmacy Reports

- Sales Report
- Stock Report
- Expiry Report
- GST/Tax Report
- Date range
- Today’s sales
- Monthly revenue
- Items sold monthly
- Average transaction
- Daily sales trend graph
- Stock by category chart
- Recent transactions
- Print
- Export PDF through print dialog

### 10. Pharmacy Settings

- Pharmacy name
- Owner name
- Phone
- GST number
- Drug license number
- Registration number
- Email
- Address
- City
- State
- PIN code
- Save changes

## Important files

- `server.py` — backend, database, authentication and APIs
- `fileserver.py` — duplicate backend file for convenience
- `index.html` — frontend web application
- `clinic.db` — SQLite database
- `README.md` — instructions

## Important production notes

Before using with real clinic/pharmacy data:

1. Change default passwords.
2. Add your real clinic/pharmacy branding.
3. Keep daily database backups.
4. Use a secure computer/server.
5. For multi-computer access, run this on one server machine in your clinic network.
6. For internet access, use HTTPS, firewall and proper deployment security.
